const canvas = document.getElementById("gameCanvas");
const ctx = canvas.getContext("2d");

// Set canvas size
const tileSize = 30;
const tileCount = 20; // 20x20 grid
canvas.width = tileSize * tileCount;
canvas.height = tileSize * tileCount;

// Game variables
let pacman = {
    x: tileSize * 1,
    y: tileSize * 1,
    size: tileSize / 1.5,
    speed: tileSize / 4,  // Slower speed (15 pixels per move)
    dx: tileSize / 4,
    dy: 0
};



const walls = [
    // Horizontal walls
    { x: 0, y: 0, width: canvas.width, height: tileSize },
    { x: 0, y: canvas.height - tileSize, width: canvas.width, height: tileSize },
    
    // Vertical walls
    { x: 0, y: 0, width: tileSize, height: canvas.height },
    { x: canvas.width - tileSize, y: 0, width: tileSize, height: canvas.height },
    
    // Inner maze walls
    { x: tileSize * 3, y: tileSize * 3, width: tileSize * 14, height: tileSize },
    { x: tileSize * 3, y: tileSize * 6, width: tileSize * 3, height: tileSize },
    { x: tileSize * 10, y: tileSize * 6, width: tileSize * 3, height: tileSize },
    { x: tileSize * 8, y: tileSize * 9, width: tileSize * 5, height: tileSize }
];

let food = [];
for (let i = 0; i < tileCount; i++) {
    for (let j = 0; j < tileCount; j++) {
        if ((i > 1 && i < tileCount - 1) && (j > 1 && j < tileCount - 1)) {
            food.push({ x: i * tileSize + tileSize / 3, y: j * tileSize + tileSize / 3, size: tileSize / 6 });
        }
    }
}

// Draw the maze walls
function drawWalls() {
    ctx.fillStyle = "#444";
    walls.forEach(wall => {
        ctx.fillRect(wall.x, wall.y, wall.width, wall.height);
    });
}

// Check collision with walls
function collisionWithWalls(x, y) {
    return walls.some(wall => 
        x < wall.x + wall.width &&
        x + tileSize > wall.x &&
        y < wall.y + wall.height &&
        y + tileSize > wall.y
    );
}

// Draw Pac-Man
function drawPacman() {
    ctx.beginPath();
    ctx.arc(pacman.x + tileSize / 2, pacman.y + tileSize / 2, pacman.size, 0.2 * Math.PI, 1.8 * Math.PI); // Open mouth
    ctx.lineTo(pacman.x + tileSize / 2, pacman.y + tileSize / 2); // Draw to center
    ctx.fillStyle = "red";
    ctx.fill();
    ctx.closePath();
}

// Draw food dots
function drawFood() {
    ctx.fillStyle = "white";
    food.forEach(dot => {
        ctx.beginPath();
        ctx.arc(dot.x, dot.y, dot.size, 0, Math.PI * 2);
        ctx.fill();
        ctx.closePath();
    });
}

// Move Pac-Man
function movePacman() {
    const nextX = pacman.x + pacman.dx;
    const nextY = pacman.y + pacman.dy;

    if (!collisionWithWalls(nextX, nextY)) {
        pacman.x = nextX;
        pacman.y = nextY;
    }
}

// Eat food
function eatFood() {
    food = food.filter(dot => {
        const distance = Math.hypot(dot.x - (pacman.x + tileSize / 2), dot.y - (pacman.y + tileSize / 2));
        return distance > pacman.size;
    });
}

// Clear the canvas
function clearCanvas() {
    ctx.clearRect(0, 0, canvas.width, canvas.height);
}

// Update game
function update() {
    clearCanvas();
    drawWalls();
    drawFood();
    drawPacman();
    eatFood();
    movePacman();
    requestAnimationFrame(update);
}

// Keyboard event listeners
function changeDirection(e) {
    switch (e.key) {
        case "ArrowRight":
            if (!collisionWithWalls(pacman.x + tileSize, pacman.y)) {
                pacman.dx = pacman.speed;
                pacman.dy = 0;
            }
            break;
        case "ArrowLeft":
            if (!collisionWithWalls(pacman.x - tileSize, pacman.y)) {
                pacman.dx = -pacman.speed;
                pacman.dy = 0;
            }
            break;
        case "ArrowUp":
            if (!collisionWithWalls(pacman.x, pacman.y - tileSize)) {
                pacman.dx = 0;
                pacman.dy = -pacman.speed;
            }
            break;
        case "ArrowDown":
            if (!collisionWithWalls(pacman.x, pacman.y + tileSize)) {
                pacman.dx = 0;
                pacman.dy = pacman.speed;
            }
            break;
    }
}

// Event listener for key presses
document.addEventListener("keydown", changeDirection);

// Start the game
update();
